import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import aiss.model.lol.champion.ChampionID;
import aiss.model.resource.LoLResource;

public class ChampionIDTest {

	static LoLResource lolres = new LoLResource();

	@Test
	public void TestChampionId() {
		Integer id = 1;

		ChampionID champ = lolres.getChampionName(id);
		assertNotNull("El test no ha funcionado", champ);
	}

}
