package aiss.model.resource;

public class LoLStreamsResource {

	private String uri = "";

}
