package aiss.model.resource;

import java.util.logging.Logger;

import org.restlet.resource.ClientResource;
import org.restlet.resource.ResourceException;

import aiss.model.lol.LoLID;

public class LoLResource {
	private static final String uri = "https://euw1.api.riotgames.com/lol/summoner/v3/summoners/by-name";
	private static final String apiKey = "?api_key=RGAPI-50d7cb0c-1a86-43b1-bc0c-c7c55f5eb730";
	private static final Logger log = Logger.getLogger(LoLResource.class.getName());

	public LoLID getSummoner(String summonerName) {
		ClientResource cr = null;
		LoLID id = null;

		try {
			cr = new ClientResource(uri + "/" + summonerName + apiKey);
			id = cr.get(LoLID.class);
		} catch (ResourceException re) {
			System.err.println("Error: " + cr.getResponse().getStatus());
		}

		return id;
	}
}