import static org.junit.Assert.assertNotNull;

import org.junit.Assert;
import org.junit.Test;

import aiss.model.resource.FacebookResource;

public class FacebookTest {

	static String pene = "prueba";

	@Test
	public void testFb() {
		FacebookResource fbres = new FacebookResource("");
		fbres.publishPost("prueba");
		Assert.assertNotNull("El test no ha cunvionado", fbres);
	}

}
